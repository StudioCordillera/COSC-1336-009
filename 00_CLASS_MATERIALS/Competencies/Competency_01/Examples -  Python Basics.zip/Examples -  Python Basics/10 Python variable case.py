# Name      
# Date      August 27, 2020
# Project#
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# Demonstrate case sensitive
# ----------------------------------------------------------------

# initialize variables
age = 15
Age = 12

#print 
print ("The value of the variable upper case X ", Age)
print ("The value of the variable lower case x ", age)

