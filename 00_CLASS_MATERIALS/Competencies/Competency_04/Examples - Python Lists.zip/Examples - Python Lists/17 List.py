# Repetition of List

list1 = ['Ally', 'Baba']
list2 = list1 *4

print(list2)


