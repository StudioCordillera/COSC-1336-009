# This program will find the hypotenuse of a right triangle
import math

a = 3
b = 4
c = math.hypot(a, b)
print('The hypotenuse is ' ,c)
