checks = (10, 20, 30)

# Add two tuples.
more = checks + checks
print(more)

# Multiply tuple.
total = 3 * checks 
print(total)

total = 3 * checks[:1]
print(total)
