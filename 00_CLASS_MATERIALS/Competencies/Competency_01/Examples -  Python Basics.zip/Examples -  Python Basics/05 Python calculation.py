# Name      
# Date      August 27, 2020
# Project#
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# Demonstrate declaring variable and calculation
# ----------------------------------------------------------------

# initialize variables
numberOne = 24
numberTwo = 7

# adds the numbers
total = numberOne + numberTwo

# print 
print ("My sum is ", total)



