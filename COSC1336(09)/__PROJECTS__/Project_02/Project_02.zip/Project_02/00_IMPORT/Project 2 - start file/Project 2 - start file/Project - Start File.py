# ---------------------------------------------
# Name: Ally Baba
# Date: xx, 20xx
# Project: Project 2
# Status: WIP
# Class: COSC 1336
# ---------------------------------------------
# Project Objectives
# 
# ---------------------------------------------

# This function will display the start of the project
def projectStart():
    print('Start of Project 2')
    print('Written by: ')
    print('Date: ')
    print('-' * 50 + '\n')
    print('\tDistribution of revenues for a Movie Theatre')
    print('-' * 50 + '\n')

# This function will display the start of the project
def projectEnd():
    print('-' * 50 + '\n')
    print('End of Project 2')

# This function will return an integer input from the user
def getIntegerData(prompt):
    value = int(input(prompt))
    return value

# This function will return a float input from the user
def getFloatData(prompt):
    value = float(input(prompt))
    return value

# This function will return a string input from the user
def getStringData(prompt):
    value = input(prompt)
    return value

def main(): 
    # Calls function to display the start of project
    projectStart()

    # Below we start writing out code

    # Calls function to display the start of project
    projectEnd()
      
main() # calling the function main()


