# delete tuple

tup = ('physics', 'chemistry', 1997, 2000);

print (tup)
del tup;
print ("After deleting tup : ")
# print (tup) - an exception raisedtup does not exis
