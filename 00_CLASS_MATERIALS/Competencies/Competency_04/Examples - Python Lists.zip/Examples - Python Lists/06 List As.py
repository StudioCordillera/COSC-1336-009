# filtering
li = [90, 84, 85, 25] 

As = [elem for elem in li if elem >= 80 and elem < 90 ]
print(As)
print(len(As))
