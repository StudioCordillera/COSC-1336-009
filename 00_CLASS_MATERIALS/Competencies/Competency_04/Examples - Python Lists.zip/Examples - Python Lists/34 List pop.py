# pop
aList = [123, 'xyz', 'zara', 'abc', 123];
print(aList)
aList.pop()
print ("List after the 1st pop : ", aList)
print ("Element which is popped : ", aList.pop(2))
print ("List after the next pop : ", aList)
