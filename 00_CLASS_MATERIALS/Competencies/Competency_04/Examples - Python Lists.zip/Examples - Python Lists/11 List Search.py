# search
inventory = ["sword", "armor", "shield", "healing potion"]

if "healing potion" in inventory:
    print ("You will live to fight another day.")
