# Return the number of times x appears in the list. 

a = [66.25, 333, 333, 1, 1234.5]

print(a.count(333))
