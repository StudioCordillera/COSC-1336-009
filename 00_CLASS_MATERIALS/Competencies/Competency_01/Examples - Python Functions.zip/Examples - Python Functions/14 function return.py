# Name      Ally Baba
# Date      February 7 2020
# Program   Function
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# 
# Function used as an assignment


def functionAsReturn(num):
    num = num + 4
    sums = 100
    return sums

def main():
    num = 10
    score = functionAsReturn(num)
    print("The score is ", score)

main()
