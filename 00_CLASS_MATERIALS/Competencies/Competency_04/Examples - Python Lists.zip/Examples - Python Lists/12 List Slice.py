# slicing
a = ['spam', 'eggs', 100, 1234]
print(a[0])

print(a[3])

print (a[-2])

print (a[:2] + ['bacon', 2*2])

print (3*a[:3] + ['Boo!'])
