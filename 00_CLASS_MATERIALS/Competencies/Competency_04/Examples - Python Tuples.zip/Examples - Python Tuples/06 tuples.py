# Create packed tuple.
pair = ("A12345", "Ally Baba")

# Unpack tuple.
(key, value) = pair

# Display unpacked variables.
print(key)
print(value)
