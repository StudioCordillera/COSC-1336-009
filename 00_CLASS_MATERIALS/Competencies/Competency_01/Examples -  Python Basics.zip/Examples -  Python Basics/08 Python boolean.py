# Name      
# Date      August 27, 2020
# Project#
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# Demonstrate Boolean variable
# ----------------------------------------------------------------

# initialize variables
number = True
check = 4 == 5

# print 
print ("boolean value is ", number)
print ("check 2 numbers ", check)
