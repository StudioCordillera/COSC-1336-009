# Name      
# Date      August 27, 2020
# Project#
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# Demonstrate how to use 2 calculation in 1 line
# ----------------------------------------------------------------

# initialize variables
number1, number2,  = 3 + 5, 3 % 4

# print 
print ("first calculation ", number1)
print ("second calculation ", number2)
