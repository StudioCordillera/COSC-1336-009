# remove

aList = [123, 'xyz', 'zara', 'abc', 'xyz'];

aList.remove('xyz');
print ("List : ", aList)
