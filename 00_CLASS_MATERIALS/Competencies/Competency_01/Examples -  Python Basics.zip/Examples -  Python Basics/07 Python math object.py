# Name      
# Date      August 27, 2020
# Project#
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# Demonstrate calling pre-defined math objects
# ----------------------------------------------------------------

# import objects
import math

# initialize variables
number = 2

# performing math operations
power = math.pow(number,2)
root = math.sqrt(number)
piValue = math.pi


# outputtind results 
print ("square of 2 is ", power)
print ("square root of 2 is ", root)
print ("pi value is ", piValue)
