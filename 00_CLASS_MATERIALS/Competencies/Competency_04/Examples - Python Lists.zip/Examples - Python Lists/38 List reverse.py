# reverse

aList = [123, 'xyz', 'zara', 'abc', 'xyz'];

aList.reverse();
print ("List : ", aList)
