# sort

aList = ['123', 'xyz', 'zara', 'abc', 'xyz'];

aList.sort();
print ("List : ", aList)

