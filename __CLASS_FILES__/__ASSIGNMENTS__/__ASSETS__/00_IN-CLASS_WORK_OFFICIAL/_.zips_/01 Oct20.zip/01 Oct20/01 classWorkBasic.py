print("I am AllyBaba")
