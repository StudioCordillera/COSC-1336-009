a = set('allybabafortytheives')
b = set('allybaba')
print(b)
print(a)

