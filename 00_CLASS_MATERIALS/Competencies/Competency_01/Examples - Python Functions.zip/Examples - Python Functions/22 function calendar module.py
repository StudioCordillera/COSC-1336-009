import calendar

print('This month calendar ', calendar.month(2017,6))
