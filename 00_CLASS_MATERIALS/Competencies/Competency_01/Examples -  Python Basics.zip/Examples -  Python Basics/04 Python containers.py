# Name      
# Date      August 27, 2020
# Project#
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# Demonstrate declaring variables and printing
# ----------------------------------------------------------------

# initialize variables
firstName = "Baba"
age = 95

# print 
print ("My name is ", firstName, " and my age is ", age)


