# index

aList = [123, 'xyz', 'zara', 'abc'];


print ("Index for xyz : ", aList.index( 'xyz' ) )
print ("Index for zara : ", aList.index( 'zara' ) )
