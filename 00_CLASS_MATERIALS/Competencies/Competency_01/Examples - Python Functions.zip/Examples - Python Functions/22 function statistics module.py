import statistics

print('The mode is ', statistics.mode([1,1,2,1,3]))
