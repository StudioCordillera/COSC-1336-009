import time

print('The current time is ',time.strftime('%X %x %Z'))#
#%x	Locale’s appropriate date representation.	 
#%X	Locale’s appropriate time representation.
#%Z	Time zone name (no characters if no time zone exists).
