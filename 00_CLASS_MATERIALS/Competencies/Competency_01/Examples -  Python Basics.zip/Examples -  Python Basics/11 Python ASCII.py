# Name      
# Date      August 27, 2020
# Project#
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# Demonstrate ASCII
# ----------------------------------------------------------------

# initialize variables
initial = 'a'
asciiValue = 97

#print 
print ("The ASCII representation of a character ", ord(initial))
print ("The character representation of a ASCII number  ", chr(asciiValue))
