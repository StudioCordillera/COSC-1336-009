# copy

tuple1 = [1, 2, 3]
tuple2 = tuple1

print('The new tupleis : ', tuple2)
