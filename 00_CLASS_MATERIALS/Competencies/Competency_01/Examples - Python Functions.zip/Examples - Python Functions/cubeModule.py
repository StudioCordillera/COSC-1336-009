# This will a module created by me
# it finds the cube of a number

def cube(number):
    return number * number * number

