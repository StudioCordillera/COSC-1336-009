alphabets = ['a', 'b', 'c', 123]                       
print(alphabets )

list1 = ['d', 'e', 'f']
alphabets.extend(list1)  
print(' after extend ', alphabets )

print(alphabets[4] )
