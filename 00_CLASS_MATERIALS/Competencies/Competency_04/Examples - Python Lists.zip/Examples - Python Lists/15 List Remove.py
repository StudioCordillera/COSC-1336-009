# remove
a = ['spam', 'eggs', 100, 1234]
print(a)
# Remove some:
a[0:2] = []
print(a)
