# count
aTuple = [123, 'xyz', 'zara', 'abc', 123];
print ("Count for 123 : ", aTuple.count(123))
