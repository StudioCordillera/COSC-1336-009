# Name      AllyBaba
# Date      August 27, 2020
# Project#
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# What is the functionality of this program
# ----------------------------------------------------------------

print ("All ssignments must include the comments above")
