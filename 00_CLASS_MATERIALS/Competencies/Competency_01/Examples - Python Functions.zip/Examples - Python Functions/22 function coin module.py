# This program will toss a coin
import random

coinToss = random.randint(0, 1)
print('1 is for head; 0 is for tail;  And I got' ,coinToss)
