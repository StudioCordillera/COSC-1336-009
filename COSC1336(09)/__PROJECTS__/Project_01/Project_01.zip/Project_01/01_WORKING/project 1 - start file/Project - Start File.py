# ---------------------------------------------
# Name: Ally Baba
# Date: , 20xx
# Project: Project 1
# Status: WIP
# Class: COSC 1336
# ---------------------------------------------
# Project Objectives
# 
# ---------------------------------------------

def main(): 
    # Project start
    print('Start of Project 1')
    print('-' * 30 + '\n')

    # Below we start writing out code

    # project end
    print('\n' + '-' * 30)
    print('\nEnd of Project 1')
      
main() # calling the function main()


