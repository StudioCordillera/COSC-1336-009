# Name      Ally Baba
# Date      February 7 2020
# Program   Function
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# Python functions start with def.  They take parameters, which are
# un-typed, as other variables.
# The string at the start of the function is for documentation.

def prHello():
    print ("Hello, World!")

prHello()
