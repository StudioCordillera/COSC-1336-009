# sort and reverse list. 
scores = ["1","2","3"]

scores.sort()

for score in scores:
   print(score)


scores.reverse()        # want the highest number first


# list high-score table
for score in scores:
   print(score)
