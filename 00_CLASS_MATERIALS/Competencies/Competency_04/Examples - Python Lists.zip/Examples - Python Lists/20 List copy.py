# copy

list1 = [1, 2, 3]
list2 = list1

print(list2)

