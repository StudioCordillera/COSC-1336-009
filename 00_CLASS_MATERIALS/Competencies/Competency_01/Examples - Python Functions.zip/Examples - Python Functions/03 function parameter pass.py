# Name      Ally Baba
# Date      February 7 2020
# Program   Function
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description

def justCall(temp):
  print ("The number is in the justCall function ", number)

number = 23
justCall(number)
print("The number is in the code", number)
