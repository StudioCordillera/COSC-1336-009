pair = ("dog", "cat")

# Search for a value.
if "cat" in pair:
    print("Cat found")

# Search for a value not present.
if "bird" not in pair:
    print("Bird not found")
