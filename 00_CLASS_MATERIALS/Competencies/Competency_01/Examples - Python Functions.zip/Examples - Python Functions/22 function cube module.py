# This program will find the hypotenuse of a right triangle
import cubeModule

value = cubeModule.cube(2)
print('The cube of 2 is ' , value)
