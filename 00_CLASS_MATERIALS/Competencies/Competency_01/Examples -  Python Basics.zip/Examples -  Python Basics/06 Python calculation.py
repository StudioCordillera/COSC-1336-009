# Name      
# Date      August 27, 2020
# Project#
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# Demonstrate declaring variable and calculation
# ----------------------------------------------------------------

# initialize variables
number1 = 24
number2 = 7

# all order of operations between the numbers
total = number1 + number2
difference = number1 - number2
product = number1 * number2
divReal = number1 / number2
divInt = number1 // number2
modulus = number1 % number2
power = number1 ** 2

# outputting the results to screen 
print ("My sum is ", total)
print ("My difference is ", difference)
print ("My product is ", product)
print ("My division of Real numbers is ", divReal)
print ("My division for integer number is ", divInt)
print ("My modulus is ", modulus)
print ("My square of 24 is ", power)


