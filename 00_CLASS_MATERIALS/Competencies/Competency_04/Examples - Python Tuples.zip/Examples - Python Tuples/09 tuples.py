# Max and min for strings.
friends = ("sandy", "michael", "aaron", "stacy")

print(max(friends))
print(min(friends))

# Max and min for numbers.
earnings = (1000, 2000, 500, 4000)

print(max(earnings))
print(min(earnings))
