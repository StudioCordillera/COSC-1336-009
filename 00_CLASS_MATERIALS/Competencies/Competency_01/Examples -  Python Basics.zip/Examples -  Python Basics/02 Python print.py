# Python starts at the first column
# for printing any string, single or double quote can be used

print("My Program")
print('My Program')
