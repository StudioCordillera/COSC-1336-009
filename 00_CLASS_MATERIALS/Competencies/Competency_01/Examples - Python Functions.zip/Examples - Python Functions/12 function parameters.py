def main(num1 = 10, num2 = 7):
    num1 = num2 = 7
    print(num1, num2)
    
num1 = 10    
num2 = 7
sum = 0
main(num1 = 10, num2 = 7)  
print(num1, num2)
