# Name      Donald Duck
# Date      August 27, 2015
# Program   Documentation
# Class     COSC 1336 Programming Language 1
# ----------------------------------------------------------------
# Description
# Function used as an assignment


def test(num):
    num = num + 4
    sum = 100
    return sum

def main():
    num = 10
    score = test(num)
    print(score)

main()
