tuples = ('cat', 'dog', 'mouse')

tuples[0] = 'feline'
