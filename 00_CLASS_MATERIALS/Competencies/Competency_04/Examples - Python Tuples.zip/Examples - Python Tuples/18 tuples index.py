# index
aTuple = (123, 'xyz', 'zara', 'abc')
print ("Index for xyz : ", aTuple.index( 'xyz' ) )
print ("Index for zara : ", aTuple.index( 'zara' ) )
