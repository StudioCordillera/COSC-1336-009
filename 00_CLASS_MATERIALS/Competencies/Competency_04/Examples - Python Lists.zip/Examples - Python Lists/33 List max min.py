# max and Min function

list1, list2 = ['123', 'xyz', 'zara', 'abc'], [456, 700, 200]

print ("Max value element : ", max(list1))
print ("Min value element : ", min(list2))
