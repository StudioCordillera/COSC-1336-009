#     Add an item to the end of the list; equivalent to a[len(a):] = [x]. 

a = [66.25, 333, 333, 1, 1234.5]

a.append(333)
print(a)
