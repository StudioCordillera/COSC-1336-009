# fucntion
def main(lst):
    print ('The list in the array is : ', lst)
    lst.append(4)


list1 = [1, 2, 3]
main(list1)
print('The List after passed through an array is : ', list1)

