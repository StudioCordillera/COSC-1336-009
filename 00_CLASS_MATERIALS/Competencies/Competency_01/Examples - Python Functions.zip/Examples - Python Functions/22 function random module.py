import random

number = random.randint(1,6)
print('An integer between 1 and 6 is ' ,number)
