# fReplace
a = ['spam', 'eggs', 100, 1234]
# Replace some items:
a[0:2] = [1, 12]
print (a)
