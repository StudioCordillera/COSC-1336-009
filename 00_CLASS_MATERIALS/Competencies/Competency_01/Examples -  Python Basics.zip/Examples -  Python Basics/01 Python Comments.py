# Comments are very importnt to undertsand the semantics of the code

