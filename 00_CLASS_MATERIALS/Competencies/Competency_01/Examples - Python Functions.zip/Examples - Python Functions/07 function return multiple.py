# function returns multiple values
def AddMoney():
   return 1, 2, 3

x, y, z = AddMoney()
print (x,y,z)
